<?php
// Text
$_['text_notification']    = 'Notifications';
$_['text_order']           = 'Orders';
$_['text_pending_status']  = 'Pending';
$_['text_complete_status'] = 'Complete';
$_['text_return']          = 'Returns';
$_['text_customer']        = 'Customers';
$_['text_online']          = 'Customers online';
$_['text_deleted']         = 'Deleted accounts';
$_['text_approval']        = 'Pending approval';
$_['text_product']         = 'Products';
$_['text_stock']           = 'Out of stock';
$_['text_low_stock']       = 'Low stock';
$_['text_review']          = 'Reviews';
$_['text_affiliate']       = 'Affiliates';
$_['text_article']         = 'Blog Articles';
