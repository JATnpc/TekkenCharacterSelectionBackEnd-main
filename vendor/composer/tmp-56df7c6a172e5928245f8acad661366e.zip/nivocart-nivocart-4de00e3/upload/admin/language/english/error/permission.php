<?php
// Heading
$_['heading_title']   = 'Permission Denied!';

// Text
$_['text_permission'] = 'You do not have permission to access this page! Please refer to your System Administrator.';
