<?php
// Heading
$_['heading_title']     = 'Robots Online Report';

// Text
$_['text_tracking']     = 'You must enable "Robots Online" in your Settings to view this report.';

// Column
$_['column_ip']         = 'IP';
$_['column_robot']      = 'Robot';
$_['column_user_agent'] = 'User Agent';
$_['column_date_added'] = 'Last Visit';
$_['column_action']     = 'Action';
