<?php
// Heading
$_['heading_title']     = 'Product Labels Report';

// Column
$_['column_product_id'] = 'ID';
$_['column_name']       = 'Name';
$_['column_image']      = 'Image';
$_['column_label']      = 'Label';
$_['column_price']      = 'Price';
$_['column_cost']       = 'Cost';
