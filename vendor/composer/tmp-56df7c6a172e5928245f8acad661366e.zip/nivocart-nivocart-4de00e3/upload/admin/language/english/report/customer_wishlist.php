<?php
// Heading
$_['heading_title']     = 'Customer Wishlist Report';

// Column
$_['column_name']       = 'Product Name';
$_['column_model']      = 'Model';
$_['column_wishlisted'] = 'Wishlisted';
$_['column_percent']    = 'Percent';
