<?php
// Text
$_['text_footer'] = '<a href="https://nivocart.com">NivoCart</a> &copy; ' . date('Y') . ' All Rights Reserved.<br />Version %s';
