<?php
// Heading
$_['heading_title']     = 'Customer Countries Report';

// Column
$_['column_country_id'] = 'ID';
$_['column_name']       = 'Country Name';
$_['column_customers']  = 'Customers';
$_['column_ratio']      = 'Ratio';
$_['column_graph']      = 'Graph';
