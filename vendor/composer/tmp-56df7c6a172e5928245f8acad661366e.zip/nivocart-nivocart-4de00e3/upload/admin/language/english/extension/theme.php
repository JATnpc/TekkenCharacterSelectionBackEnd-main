<?php
// Heading
$_['heading_title']    = 'Themes';

// Text
$_['text_install']     = 'Install';
$_['text_uninstall']   = 'Uninstall';
$_['text_is_active']   = '<b>(Active)</b>';

// Column
$_['column_name']      = 'Theme Name';
$_['column_action']    = 'Action';

// Button
$_['button_settings']  = 'Settings';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify <b>Themes</b> !';
