<?php
// Heading
$_['heading_title']     = 'Customers Deleted Report';

// Column
$_['column_id']         = 'ID';
$_['column_name']       = 'Name';
$_['column_email']      = 'Email';
$_['column_orders']     = 'Orders';
$_['column_date_added'] = 'Date Deleted';
