<?php
// Heading
$_['heading_title']        = 'Install';

// Text
$_['text_install_message'] = 'Missing Database Tables!';
$_['text_upgrade']         = 'Go to "modification/blog" to Install';

// Error
$_['error_database']       = 'Database Not Found!';
