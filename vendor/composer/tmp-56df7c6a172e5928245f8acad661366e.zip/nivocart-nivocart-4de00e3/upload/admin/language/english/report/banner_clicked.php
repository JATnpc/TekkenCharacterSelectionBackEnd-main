<?php
// Heading
$_['heading_title']  = 'Banner Clicked Report';

// Text
$_['text_success']   = 'Success: You have reset the banner clicked report!';

// Column
$_['column_id']      = 'ID';
$_['column_image']   = 'Image';
$_['column_title']   = 'Title';
$_['column_link']    = 'Link';
$_['column_clicked'] = 'Clicks';
$_['column_percent'] = 'Percent';
